#
# Cookbook:: Converter_Cookbook
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.
Chef::Log.info("********** Hello, Chef! **********")